package com.gpl.rpg.AndorsTrail.controller.listeners;

public interface GameRoundListener {
	void onNewTick();
	void onNewRound();
	void onNewFullRound();
}
